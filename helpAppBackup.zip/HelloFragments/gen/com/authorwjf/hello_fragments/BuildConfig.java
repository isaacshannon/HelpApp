/** Automatically generated file. DO NOT MODIFY */
package com.authorwjf.hello_fragments;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}